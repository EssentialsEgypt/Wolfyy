"use client"

import { Phase1MainDashboard } from "@/components/dashboard/phase1-main-dashboard"

export default function DashboardPage() {
  return <Phase1MainDashboard />
}
