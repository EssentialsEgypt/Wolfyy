import { EnhancedSocialMediaDashboard } from "@/components/dashboard/enhanced-social-media-dashboard"

export default function Home() {
  return <EnhancedSocialMediaDashboard />
}
