(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@supabase_node-fetch_browser_85c09f9b.js",
  "static/chunks/_0d6cf9e2._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_lodash_20634561._.js",
  "static/chunks/node_modules_recharts_es6_dddff71f._.js",
  "static/chunks/node_modules_@supabase_auth-js_dist_module_6004bf20._.js",
  "static/chunks/node_modules_@radix-ui_6598c30c._.js",
  "static/chunks/node_modules_@floating-ui_9ec1fa39._.js",
  "static/chunks/node_modules_@supabase_068ff586._.js",
  "static/chunks/node_modules_56021979._.js"
],
    source: "dynamic"
});
