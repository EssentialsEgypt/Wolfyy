(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@supabase_node-fetch_browser_27a70c0e.js",
  "static/chunks/node_modules_418d5a07._.js",
  "static/chunks/src_3b409ac2._.js"
],
    source: "dynamic"
});
