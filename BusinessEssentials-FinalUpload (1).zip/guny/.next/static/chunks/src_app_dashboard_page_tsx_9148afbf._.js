(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@supabase_node-fetch_browser_e86af9ed.js",
  "static/chunks/src_3df03b8b._.js",
  "static/chunks/node_modules_d5c4ab04._.js"
],
    source: "dynamic"
});
